make -f makefile.accessesULCC
sleep 1
sd=10
col=50

for (( rep=1;rep<=50;rep++))
do
numactl --physcpubind=0 --membind=0 perf stat --output=perf-out --append -B -e cache-misses,cache-references,LLC-prefetches  ./accesses $sd 64 $col
sleep 1
bash arrange.sh >> data.solo.$sd.ULCC.$col
done
sort -n data.solo.$sd.ULCC.$col --output=data.solo.$sd.ULCC.$col
