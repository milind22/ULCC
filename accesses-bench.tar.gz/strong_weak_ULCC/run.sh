make -f makefile.accessesULCC
sleep 1
make -f makefile.infiniteULCC
sleep 1

sd_strong=10
sd_weak=50

col_strong=50
col_weak=10

for (( rep=1;rep<=10;rep++))
do
numactl --physcpubind=2 --membind=0 ./infinite $sd_weak 64 $col_weak &
sleep 1
numactl --physcpubind=0 --membind=0 perf stat --output=perf-out --append -B -e cache-misses,cache-references,LLC-prefetches  ./accesses $sd_strong 64 $col_strong
sleep 1
pkill infinite
bash arrange.sh >> data_strong.$sd_strong.$col_strong.weak.$sd_weak.$col_weak.ULCC
done
sort -n data_strong.$sd_strong.$col_strong.weak.$sd_weak.$col_weak.ULCC --output=data_strong.$sd_strong.$col_strong.weak.$sd_weak.$col_weak.ULCC
